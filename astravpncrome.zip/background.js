chrome.runtime.onInstalled.addListener(() => {
  console.log('ASTRACAT VPN extension installed.');
});

chrome.proxy.onProxyError.addListener((error) => {
  console.error('Proxy error:', error);
});
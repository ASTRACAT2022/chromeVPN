const vpnToggle = document.getElementById('vpnToggle');
const statusText = document.getElementById('status');
const testButton = document.getElementById('testButton');

vpnToggle.addEventListener('change', () => {
  if (vpnToggle.checked) {
    connectVPN();
  } else {
    disconnectVPN();
  }
});

testButton.addEventListener('click', () => {
  window.open('https://astracat2022.github.io/test/');
});

function connectVPN() {
  chrome.proxy.settings.set({
    value: {
      mode: 'fixed_servers',
      rules: {
        singleProxy: {
          scheme: 'http',
          host: '85.209.2.112',
          port: 7777
        },
        bypassList: ['localhost']
      }
    },
    scope: 'regular'
  }, () => {
    statusText.textContent = 'Connected';
    statusText.style.color = 'green';
  });
}

function disconnectVPN() {
  chrome.proxy.settings.clear({
    scope: 'regular'
  }, () => {
    statusText.textContent = 'Disconnected';
    statusText.style.color = 'red';
  });
}